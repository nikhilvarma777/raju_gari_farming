export default function App() {
  return (
    <main style={{ padding: "20px", fontFamily: "Arial" }}>
      <header style={{ background: "#228B22", color: "white", padding: "20px", borderRadius: "10px" }}>
        <h1>🌾 Raju Gari Farming 🧺</h1>
        <p>Fresh Crops • Local Prices • Direct to You</p>
      </header>

      <section style={{ marginTop: "20px" }}>
        <h2>🌿 Available Crops</h2>
        <ul>
          <li><strong>Gongura:</strong> ₹35/kg</li>
          <li><strong>Green Chillies:</strong> ₹55/kg</li>
          <li><strong>Thotakura:</strong> ₹25/kg</li>
        </ul>
      </section>

      <footer style={{ marginTop: "40px", fontSize: "0.8em", color: "#666" }}>
        © 2025 Raju Gari Farming 🧺 — Grown with care in Andhra Pradesh.
      </footer>
    </main>
  );
}